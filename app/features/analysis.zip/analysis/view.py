from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QStackedWidget,
)

from app.core import Frame, show_error
from app.core.app_state import AppState
from app.core.exceptions import ValidationError

from .service import AnalysisService
from .views.forecast_view import ForecastView
from .views.trends_view import TrendsView
from .widgets.tab_bar import TabBar

from app.features.wallets.service import WalletService
from app.features.wallets.widgets.wallet_form_dialog import WalletFormDialog

TRENDS = "trends"
FORECAST = "forecast"

# Tabs as data so the set can become wallet-type dependent later without
# touching the layout. Investment wallets will want a different list.
TABS = [
    (TRENDS, "Trends"),
    (FORECAST, "Forecast"),
]


class AnalysisView(QWidget):
    """Shell for the Analysis section: a wallet line, tabs, two pages.

    Owns nothing but the switch. Each page talks to AnalysisService on
    its own, so adding a third tab means adding a page and a tuple.

    Pages are built once here but only load on first show, because
    QStackedWidget does not send showEvent to a page nobody has opened.
    Opening Analysis therefore costs one query set, not two.
    """

    def __init__(
        self,
        service: AnalysisService,
        wallet_service: WalletService,
        app_state: AppState,
        parent=None,
    ):
        super().__init__(parent=parent)
        self.service = service
        self.wallet_service = wallet_service
        self.app_state = app_state

        self._init_view()

        self.app_state.wallet_changed.connect(self._update_wallet_label)
        self._update_wallet_label()

    def _init_view(self):
        "Initialize view"
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setMinimumWidth(0)

        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        main_layout.addWidget(self._build_header())
        main_layout.addWidget(self._build_pages())

    def _build_header(self) -> QWidget:
        """Which wallet these numbers are about, and the tabs.

        No "Analysis" title - the sidebar button already said that. The
        wallet is the part the reader cannot infer, and every figure on
        both pages is scoped to it.
        """
        header = Frame(self, add_stylesheet=False)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 10, 10)
        header_layout.setSpacing(14)

        self.wallet_label = QLabel(header)
        self.wallet_label.setObjectName("analysisWalletLabel")
        self.wallet_label.setAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom
        )

        self.tabs = TabBar(
            parent=header,
            values=TABS,
            default_value=TRENDS,
            on_change=self._on_tab_changed,
        )

        header_layout.addWidget(self.wallet_label)
        header_layout.addStretch()
        header_layout.addWidget(self.tabs)

        return header

    def _build_pages(self) -> QWidget:
        self.trends_view = TrendsView(
            service=self.service, app_state=self.app_state, parent=self
        )
        self.forecast_view = ForecastView(
            service=self.service, app_state=self.app_state, parent=self
        )
        self.forecast_view.edit_assumptions_requested.connect(self._edit_assumptions)

        self.stacked_pages = QStackedWidget(self)
        self.stacked_pages.addWidget(self.trends_view)
        self.stacked_pages.addWidget(self.forecast_view)

        self._pages = {TRENDS: self.trends_view, FORECAST: self.forecast_view}

        return self.stacked_pages

    # EVENTS
    def _on_tab_changed(self, tab: str):
        page = self._pages.get(tab)
        if page is not None:
            self.stacked_pages.setCurrentWidget(page)

    def _update_wallet_label(self, wallet_id: int = None):
        wallet = self._active_wallet()
        if wallet is None:
            self.wallet_label.setText("No wallet selected")
            return

        self.wallet_label.setText(f"{wallet.name} · {wallet.currency}")

    def _edit_assumptions(self):
        """Open the wallet so the plan can be changed.

        Analysis does not own these fields, so it hands off to the dialog
        that does rather than growing a second editor for them. The
        dialog's save emits wallet_changed, which both pages already
        listen to.
        """
        wallet = self._active_wallet()
        if wallet is None:
            show_error(
                self,
                "Select a wallet before editing its plan.",
                title="No wallet",
            )
            return

        try:
            dialog = WalletFormDialog(
                service=self.wallet_service, wallet=wallet, parent=self
            )
        except ValidationError as error:
            show_error(self, str(error))
            return

        dialog.exec()

    def _active_wallet(self):
        wallet_id = self.app_state.active_wallet_id
        if wallet_id is None:
            return None
        return self.wallet_service.get_wallet(wallet_id=wallet_id)
