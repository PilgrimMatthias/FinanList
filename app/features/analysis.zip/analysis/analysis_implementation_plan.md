# Analysis Feature — Implementation Plan

Last v1 feature. One tabbed `AnalysisView` holding **Trends** (retrospective) and
**Forecast** (projection), scoped to the active wallet.

---

## Settled decisions

| Decision           | Choice                                                                                   |
| ------------------ | ---------------------------------------------------------------------------------------- |
| View structure     | One `AnalysisView` with tabs, not two sidebar entries                                  |
| Tab set            | Conditional on `wallet_type` — Forecast only for `normal`                           |
| Scope              | Active wallet only                                                                       |
| Plan storage       | Per wallet: `planned_monthly_income`, `planned_monthly_expenses`, `forecast_floor` |
| Plan definition    | Expenses means expenses only: recurring included, savings/investment transfers excluded  |
| Plan source        | User-entered, with a derived-average calibration hint                                    |
| Calibration window | User-selectable 3/6/12, default 6, **not persisted**                               |
| Est. other         | `max(0, plan − expenses)`, one function for every month                               |
| Current month      | `expenses = actual to date + remaining scheduled` — the only difference               |
| Floor check        | On `Closing` only                                                                      |
| Charts             | QtCharts via a shared `ThemedChartView`, **one shared Y axis**                   |
| Recalculation      | Trends on signal (debounced); Forecast on button                                         |
| Transfers          | Deferred to v2                                                                           |

### Explicitly not in v1

- Savings/investment wallets receiving contributions from a normal wallet
- Wallet-to-wallet transfers or withdrawals
- A dedicated Investment section
- All-wallets Trends (blocked on multi-currency)
- Intra-month floor breach detection
- `is_inflow` on `TRANSACTIONS`
- Type-specific meaning for the plan columns on savings/investment wallets —
  those wallets simply have `NULL` plans and no Forecast tab

### Still open

- **Floor rendering.** A full-width dashed line sits at ~20% of plot height and
  slices through every expense bar. Alternative: a red tick and label on the Y axis,
  with the red balance dots and the table's `below floor` text carrying the per-month
  detail. Decide before Phase 4.
- **Savings rate source** — see Phase 0.
- **`gross_salary`** — see Phase 0.

---

## Phase 0 — Schema and plan storage

### Explanation

The forecast needs three numbers per wallet, and today they are scattered: some
already migrated to `WALLETS`, `net_salary` and `gross_salary` still on
`USER_PROFILE`, and a summary panel in `ProfileDialog` computing from fields that
are moving out from under it.

`net_salary` and `planned_monthly_income` are the same quantity. Both currently
exist and both are writable, with nothing keeping them in sync — that is the most
urgent thing in this phase, because the forecast reads one and the profile shows
the other.

Two definitions have to be exactly right here, because everything downstream
depends on them and neither is enforced by the schema:

- **`planned_monthly_expenses` is expenses only.** Recurring payments are included;
  transfers to savings and investments are not, because the forecast takes those
  from their own scheduled items. Put this in a comment on the column and in the
  field's sub-label. If it ever drifts to "all outflow", every forecast is wrong by
  the size of the user's savings contributions and will still look plausible.
- **`NULL` means not set, `0` means genuinely zero.** A `NULL` plan runs the
  forecast on scheduled items only and prompts the user. A `NULL` floor draws no
  line and raises no warnings. Defaulting any of them to `0` gives every new wallet
  a plan and a floor it never asked for.

The summary panel ("Left each month", "Savings rate") follows its inputs into
`WalletFormDialog`. Keep it as an inline section with an object name for QSS, not a
new widget class — it has exactly one consumer, and the right time to extract it is
when a second appears.

### Plan

* [X] Three nullable `REAL` columns on `WALLETS`
* [X] `Wallet` dataclass + `COLUMNS` updated
* [X] `WalletRepo` read/write for the three fields
* [X] Confirm `sqlite3.sqlite_version >= 3.35` before relying on `DROP COLUMN`
* [X] Migrate `USER_PROFILE.net_salary` → `WALLETS.planned_monthly_income`: backfill onto the user's wallets, then drop the profile column
* [X] Decide `gross_salary` — move it onto `WALLETS` beside net, or drop it. Criterion: does anything read it today? If nothing does, this is the cheapest moment it will ever be to delete
* [X] Add a comment on `planned_monthly_expenses` stating the definition
* [X] `TransactionRepo.get_monthly_average(wallet_id, months, operation_types) -> Decimal` — one method with a parameter, not two near-duplicates
* [X] `WalletFormDialog`: three plan inputs, with the expenses sub-label spelling out the definition
* [X] Calibration hint under income and expenses, with a transient 3/6/12 selector and a **Use** action
* [X] Query the hint on dialog open and on window change only — not on amount-field keystrokes
* [X] Move the Left-each-month / Savings-rate panel into `WalletFormDialog`
* [X] Resolve the savings-rate source: make it plan-derived like its neighbour, or separate it visually so it is clear one figure responds to typing and the other does not
* [X] Audit what remains in `ProfileDialog` — if it is an avatar and one field, consider folding it into Settings

---

## Phase 1 — ThemedChartView

### Explanation

`QChart` is a `QGraphicsItem`, not a `QWidget`, so neither stylesheet reaches it.
Out of the box you get a white plot background and black axis labels in dark theme.
Every colour has to come from `Palette` in code and be re-applied on
`palette_signals.changed` — the same shape as `SvgIcon` and `LogoWidget`.

Build and verify this before anything depends on it. Chart theming bugs are much
harder to spot once there is a table, a summary strip and a popover in the way.

Two problems specific to this app: `QChartView` inherits `QGraphicsView` and accepts
wheel events, so a chart on a scrolling Analysis page traps scrolling the same way
the nested scroll areas in the due dialog did. And twelve month labels will not fit
horizontally at 800px.

### Plan

* [X] `core/widgets/themed_chart_view.py`
* [X] `setBackgroundVisible(False)` and `setPlotAreaBackgroundVisible(False)`
* [X] `setRenderHint(QPainter.RenderHint.Antialiasing)` — off by default
* [X] `restyle()` reading axis label, grid line, axis line and legend colours from `Palette`
* [X] Connect `restyle()` to `palette_signals.changed` in `__init__`
* [X] Override `wheelEvent` to `ignore()` so the parent scroll area still scrolls
* [X] Helper for axis maximum derived from the data, with headroom — never a constant
* [X] `QBarCategoryAxis.setLabelsAngle(-45)`, or three-letter Polish month forms
* [X] Verify both themes with a throwaway chart before moving on

---

## Phase 2 — Forecast engine

### Explanation

The only part of this feature with real business logic, and the only part worth
testing properly. Keep it a pure function: no `QObject`, no cursor, and no
`datetime.now()` inside — pass `today` in so tests can pin it.

**One function handles every month.** The current month differs only in that
`expenses = actual to date + remaining scheduled`; the arithmetic after that is
identical. Resist writing two code paths.

The clamp is the behaviour already in the current app. What is new is recording
*why* it fired — `over_plan_by` is the most useful number on a row and it only
exists in the value the clamp discards.

One trap the unified function introduces: `over_plan_by` means two different things.
On the current month it means "you have overspent". On a future month nothing has
happened — it means the scheduled commitments exceed the plan, so the plan is too
low for that month. Same number, different statement. The model should carry the
distinction so the view can label them differently.

Overdue occurrences land in the current month naturally, because generation starts
from `next_due_date`, which may already be in the past. That is correct — an overdue
bill genuinely is still "yet to pay" — but it depends on `advance_recurrings`
having run, which is the one invariant the forecast silently assumes.

### Plan

* [X] `ForecastMonth` dataclass: `year`, `month`, `opening`, `income`, `expenses`, `savings`, `investments`, `est_other`, `closing`, `is_current_month`, `over_plan_by`, `below_floor`
* [X] `features/analysis/forecast.py` — one pure function taking `today`
* [X] `est_other = max(0, plan − expenses)`, savings and investments outside the plan
* [X] Record `over_plan_by` when the clamp fires
* [X] Compare `closing` against the floor, skipping entirely when the floor is `NULL`
* [X] Test: current month mixes actuals and scheduled correctly
* [X] Test: overspend clamps to zero and sets `over_plan_by`
* [X] Test: a confirmed recurring appears exactly once
* [X] Test: an overdue unconfirmed occurrence lands in the current month
* [X] Test: floor breach flags the right months
* [X] Test: no plan set — runs on scheduled items only
* [X] Test: month with no scheduled items at all
* [X] Test: horizon boundary at 3, 6 and 12

---

## Phase 3 — Repo and service

### Explanation

Occurrence generation for the forecast must be **read-only**. The due dialog's path
creates transactions; the forecast must not. If the existing generator writes, split
out the pure "which occurrences fall in this window" part and let both call it.
Copying it means the two drift and the forecast eventually disagrees with Upcoming,
with no way to tell which is lying.

Aggregate in SQL, not in Python. One query grouped by `strftime('%Y-%m', date)` and
`operation_type` rather than one query per month — twelve round trips for a
button-driven view is wasteful even locally, and the same shape serves Trends.

### Plan

* [ ] Split read-only occurrence generation out of the due-dialog path
* [ ] `TransactionRepo`: monthly totals by operation type, one grouped query
* [ ] `TransactionRepo`: month-to-date actuals for the current month
* [ ] `TransactionRepo`: category aggregates for Trends (total, avg, min, max)
* [ ] `TransactionRepo`: subcategory aggregates within one parent
* [ ] `AnalysisService` orchestrating both views and owning the wallet-scope filter

---

## Phase 4 — Forecast view

### Explanation

Eight fixed columns, so one stable model and no column-changing resets:

```
Month | Opening | Income | Expenses | Savings | Investments | Est. other | Closing
```

The four typed columns are scheduled amounts and `Est. other` is the clamped
remainder, so the known/estimated boundary reads off the headers without hatching
or doubled columns.

The summary strip carries the three numbers this view actually gets opened for —
Available to spend, Yet to pay this month, Projected month end. Keeping them out of
the table means every row keeps meaning the same thing and stays comparable.

Two things from the mockup review to get right while building rather than after:

- **`over_plan_by` needs different wording on future rows.** `is_current_month` is
  already on the model; a future month showing a warning triangle and "over plan"
  tells the user they overspent in a month that has not happened. Reword it, or
  suppress it on future rows and let `Est. other` showing `0,00` carry the message.
- **Mark stale, do not auto-recalculate.** On `transaction_changed` show the banner.
  Silently redrawing under someone who is reading the table is worse than asking.

### Plan

* [ ] Summary strip with the three figures
* [ ] Popover on the Yet-to-pay tile listing the scheduled items
* [ ] `ForecastTableModel` with eight fixed columns
* [ ] Row tint and `below floor` label for breaching months
* [ ] `to date` badge on the current-month row
* [ ] `ToolTipRole` on the current month's Expenses cell: "X spent · Y scheduled"
* [ ] Different wording for `over_plan_by` on future rows
* [ ] `QStackedBarSeries` with four bar sets plus `Est. other` on a dashed light brush
* [ ] Balance as `QLineSeries` on the **same** axis as the bars
* [ ] Floor — line or axis marker, per the open decision above
* [ ] Axis maximum from `max(stacked total, balance, floor)` with headroom
* [ ] Assumptions strip with an **Edit assumptions** link opening `WalletFormDialog`
* [ ] Horizon selector 3/6/12, default 6
* [ ] Calculate button, and the stale banner with Recalculate
* [ ] Empty state for a wallet with no plan set

---

## Phase 5 — Trends view

### Explanation

The dimension switch changes **columns, not just rows**. Totals wants
`income / expense / difference / savings %` with months as rows; By-category wants
`total / monthly avg / min / max / %` with categories as rows. Those are different
column sets.

Use two models swapped into the same `QTableView` rather than one model with a
variable `columnCount`. Each stays fixed-width and keeps its own delegates. After
every `setModel()`, re-apply delegates and re-run column sizing — they do not
survive the swap, and the symptom is a table that looks fine until the second
switch.

The pinned totals row is not free in Qt. A one-row `QTableView` below the main one,
with its column widths following the main header's `sectionResized`, and a right
margin matching the scrollbar. That margin has to be **dynamic**: the scrollbar only
exists when the content overflows, so a six-row range leaves the footer misaligned
by the reserved width. Build it once as a reusable `TableFooter` — three screens
need it.

Value labels on the subcategory chart go **outside** the bars
(`LabelsOutsideEnd`). Inside-the-bar needs the bar to be taller than the text, and a
subcategory with a zero month renders a zero-height bar with an invisible label.

### Plan

* [ ] Date range inputs, default last 12 months
* [ ] Dimension selector: Totals / By category / Inside category
* [ ] `TotalsTableModel` and `CategoryTableModel`, both fixed-column
* [ ] Re-apply delegates and column sizing after every `setModel()`
* [ ] `TableFooter` widget: one-row view, width-synced, dynamic scrollbar margin
* [ ] Totals chart: `QBarSeries` with income and expense bar sets
* [ ] Hover tooltip via `QBarSeries.hovered` → `QToolTip.showText`
* [ ] Dim the in-progress month
* [ ] By-category: bar painted in the Total column by a `QStyledItemDelegate`, no chart
* [ ] Expenses/Income toggle — decide whether it persists across dimension switches
* [ ] Inside-category: chart full width above the table, `LabelsOutsideEnd`
* [ ] Row click drills from By-category into Inside-category
* [ ] Debounce range changes with a restarting `QTimer`, ~250 ms
* [ ] Empty state for a range with no transactions

---

## Phase 6 — Wiring

### Explanation

Tab construction belongs in a method that returns which tabs to build, keyed on
`wallet_type`. Adding an Investment tab in v2 is then one new widget plus one line
rather than a view refactor.

`default_page` stores a raw stacked index, so inserting Analysis shifts everything
after it. That mapping has already drifted once — audit it in the same commit.

### Plan

* [ ] `AnalysisView` with the tab set driven by `wallet_type`
* [ ] DI in `app.py`
* [ ] Rebuild on `wallet_changed`
* [ ] Mark stale on `transaction_changed`, do not recompute
* [ ] QSS for both themes, following the section order in `dark.qss` / `light.qss`
* [ ] Walk the whole feature in dark theme
* [ ] Audit `SettingsView._SECTIONS` against the real stacked order

---

## Suggested order

Phase 0 → 1 → 2 → 3 → 4, then 5, then 6.

Forecast before Trends: it is the feature you care about, it is where the real logic
lives, and it exercises `ThemedChartView` and the plan columns end to end. Trends is
mostly `GROUP BY` and a table once the chart wrapper exists.

Phase 2 before any view work. Getting the current-month arithmetic right on paper is
much easier than debugging it through a table model.
