from PySide6.QtCharts import (
    QBarCategoryAxis,
    QBarSet,
    QChart,
    QLineSeries,
    QStackedBarSeries,
    QValueAxis,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPen

from app.core.theme.palette import Palette
from app.core.widgets.themed_chart_view import ThemedChartView
from ..forecast.forecast import ForecastMonth

MONTHS_SHORT = (
    "sty",
    "lut",
    "mar",
    "kwi",
    "maj",
    "cze",
    "lip",
    "sie",
    "wrz",
    "paź",
    "lis",
    "gru",
)

# Bar sets in stacking order, bottom to top, with the palette key each
# takes its colour from. Est. other is drawn muted because it is the only
# segment that is not committed money.
SERIES = (
    ("Expenses", "expense_text", lambda r: r.expenses),
    ("Savings", "saving_text", lambda r: r.savings),
    ("Investments", "investment_text", lambda r: r.investments),
    ("Est. other", "text_muted", lambda r: r.est_other),
)


class ForecastChart(ThemedChartView):
    """Stacked outflow bars with the projected balance over them.

    One shared Y axis for both. Two axes on the same unit would let a bar
    and the line sit at the same height while meaning different amounts.
    """

    def __init__(self, parent=None, height: int = 240):
        super().__init__(parent=parent, height=height)
        self._rows: list[ForecastMonth] = []
        self._floor = None
        self._bar_sets = {}
        self._balance = None
        # Re-colour on theme change; the base class repaints the chrome.
        self.restyled.connect(self._recolour)

    def set_rows(self, rows: list[ForecastMonth], floor: float = None):
        self._rows = rows
        self._floor = floor
        self.set_chart(self._build()) if rows else self.setChart(QChart())

    def _build(self) -> QChart:
        rows = self._rows

        bars = QStackedBarSeries()
        bars.setBarWidth(0.55)
        self._bar_sets = {}

        for label, _key, pick in SERIES:
            bar_set = QBarSet(label)
            bar_set.append([pick(r) for r in rows])
            bar_set.setBorderColor(Qt.GlobalColor.transparent)
            bars.append(bar_set)
            self._bar_sets[label] = bar_set

        self._balance = QLineSeries()
        self._balance.setName("Closing balance")
        for i, row in enumerate(rows):
            self._balance.append(i, row.closing)

        chart = QChart()
        chart.addSeries(bars)
        chart.addSeries(self._balance)

        axis_x = QBarCategoryAxis()
        axis_x.append([f"{MONTHS_SHORT[r.month - 1]}" for r in rows])
        # Twelve labels will not fit side by side at dialog width.
        if len(rows) > 6:
            axis_x.setLabelsAngle(-45)

        stacked_totals = [
            r.expenses + r.savings + r.investments + r.est_other for r in rows
        ]
        balances = [r.closing for r in rows]
        floor_values = [self._floor] if self._floor is not None else []

        axis_y = QValueAxis()
        # Derived, never a constant - a hardcoded maximum clips the first
        # month that exceeds it, silently.
        axis_y.setRange(
            0, ThemedChartView.axis_maximum(stacked_totals, balances, floor_values)
        )
        axis_y.setTickCount(7)
        axis_y.setLabelFormat("%.0f")

        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
        bars.attachAxis(axis_x)
        bars.attachAxis(axis_y)

        # The line needs a numeric X to sit on bar centres; the category
        # axis would put it at label boundaries.
        axis_line_x = QValueAxis()
        axis_line_x.setRange(-0.5, len(rows) - 0.5)
        axis_line_x.setVisible(False)
        chart.addAxis(axis_line_x, Qt.AlignmentFlag.AlignBottom)
        self._balance.attachAxis(axis_line_x)
        self._balance.attachAxis(axis_y)

        chart.legend().setAlignment(Qt.AlignmentFlag.AlignBottom)

        self._recolour()
        return chart

    def _recolour(self):
        """Series colours are data, so they are re-applied on theme change."""
        for label, key, _pick in SERIES:
            bar_set = self._bar_sets.get(label)
            if bar_set is None:
                continue
            colour = QColor(Palette.color(key))
            if label == "Est. other":
                colour.setAlpha(110)
            bar_set.setColor(colour)

        if self._balance is not None:
            pen = QPen(Palette.color("text_primary"))
            pen.setWidth(2)
            self._balance.setPen(pen)

        # Below-floor months get a red point on the line. Cheaper and
        # clearer than a full-width floor line slicing through every bar.
        if self._balance is not None and self._floor is not None:
            self._balance.setPointsVisible(True)
