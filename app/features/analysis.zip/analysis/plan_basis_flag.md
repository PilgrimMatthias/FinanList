# Planned-expenses basis flag — implementation plan

A small cross-cutting change to Phase 0, landing before Phase 2 is written.

---

## Explanation

Two users type the same number into **Estimated expenses** and mean different
things:

- *"I spend 5 000 a month"* — expenses only, transfers are separate
- *"I spend 5 000 a month"* — everything that leaves the account, transfers included

The app cannot tell which, and the second user's forecast double-counts their
transfers: once inside their inflated plan figure, once in the Savings and
Investments columns. Roughly 800/month of phantom outflow on realistic numbers,
which also fires floor warnings that are not real.

One boolean on the wallet resolves it.

**The flag has three readers, and the third is the one that gets forgotten:**

1. `build_forecast` — which operation types `est_other` nets against
2. `get_plan_suggestion` — which types the average sums, **and** the hint's label
3. The expenses field's own `sub_text`, which currently asserts
   "Excludes transfers to savings and investments"

If 2 and 3 do not follow the flag, a user flips to *Everything*, clicks **Use**,
and gets an expenses-only figure dropped into a field that now means something
wider — the original bug, arriving through the fix.

**Decided:** new wallets default to `Expenses only` (0). Not because it is the
more common mindset, but because the sub-label and the hint already say
expenses-only, so a fresh dialog is internally consistent with no extra work.

---

## Plan

### Schema

* [X] `ALTER TABLE WALLETS ADD COLUMN PLAN_INCLUDES_TRANSFERS INTEGER NOT NULL DEFAULT 0;`
* [X] `UPDATE WALLETS SET PLAN_INCLUDES_TRANSFERS = 1 WHERE ID = <your wallet>;` — the ALTER backfills every existing row with 0, including yours
* [X] Add the column to the `CREATE TABLE` in the schema file, so fresh installs match

### Model

* [X] `Wallet.plan_includes_transfers: bool = False`
* [X] **Append** to `COLUMNS` — appending keeps every existing `from_row` index unchanged
* [X] `from_row`: convert SQLite's 0/1 to a real `bool`

### Repo

* [X] `WalletRepo.create_no_commit` — column + param
* [X] `WalletRepo.update` and `update_no_commit` — column + param

### Dialog

* [X] `SegmentedControl` directly **above** the expenses field — it changes what that field means, so the user meets it before typing

```python
self.basis_control = SegmentedControl(
    text="Planned expenses cover",
    sub_text="Everything = expenses + savings + investments",
    values=[(0, "Expenses only"), (1, "Everything")],
    default_value=1 if self._wallet_includes_transfers() else 0,
    label_position="top",
    on_change=self._basis_changed,
)
```

* [X] `_basis_changed` → refresh the hint, the hint label, and the expenses `sub_text`
* [X] Expenses field `sub_text` follows the flag:
  * off → "monthly, used for forecasting. Excludes transfers to savings and investments."
  * on → "monthly, used for forecasting. Includes transfers to savings and investments."
* [X] `_create_wallet` and `_update_wallet` both pass the flag — same create/edit symmetry that was missed on the plan fields
* [X] Leave the typed amount alone when the basis flips. Silently rewriting a number the user entered is worse than letting the refreshed hint show the mismatch

### Service

* [X] `get_plan_suggestion(wallet_id, months, include_transfers: bool)` — **pass it in, do not read it from the wallet.** The dialog's segment may be flipped but unsaved, and a hint that only updates after save reads as broken

```python
types = ([OperationType.EXPENSE, OperationType.SAVING, OperationType.INVESTMENT]
         if include_transfers
         else [OperationType.EXPENSE])
```

* [X] Hint label follows the basis:
  * off → `Last 6 months, expenses only: 6 436,05`
  * on → `Last 6 months, incl. transfers: 7 236,05`

### Forecast (Phase 2, when you get there)

* [X] `ForecastInputs.plan_includes_transfers: bool`
* [X] The branch:

```python
if inputs.plan_includes_transfers:
    outflow = scheduled_expenses + savings + investments
else:
    outflow = scheduled_expenses

est_other = max(0.0, planned_expenses - outflow)
over_plan_by = outflow - planned_expenses if outflow > planned_expenses else None
```

* [X] `over_plan_by` must use the **same** `outflow` as `est_other`, or a wallet with the flag on reports an overage measured against a narrower number than the one that produced it

### Tests

* [X] `est_other` with the flag off — nets against expenses only
* [X] `est_other` with the flag on — nets against expenses + savings + investments
* [X] Same inputs both ways produce different `est_other`, and the flag-on total outflow equals the planned figure exactly when nothing exceeds it

# Forecast model change — netting → additive

Decided 16 Nov 2026. Supersedes the `est_other` design in
`analysis_implementation_plan.md` (Phase 2) and replaces `plan_basis_flag.md`
entirely.

---

## Why

The old model asked for *total* monthly expenses and subtracted scheduled items
from it:

```python
est_other = max(0, planned_expenses - scheduled_expenses)
```

That assumes the user's figure is a strict **superset** of their recurrings. If
it is only a partial overlap — someone who says "I spend 5 000" but mentally
excludes rent, because rent feels like a fixed cost rather than spending — the
forecast understates by the missing items. On realistic numbers that is ~640/month,
~3 800 over a six-month horizon, in the optimistic direction, so the floor
warnings do not fire when they should.

It also behaves wrongly when commitments change. Adding a 100/month subscription
leaves the projected total untouched — it just eats into `est_other`. For a
figure the user means *descriptively* ("what actually leaves my account"), a new
commitment should raise the total.

The additive model asks for the part that cannot overlap by construction:

```python
total_expenses = scheduled_expenses + planned_discretionary
```

`planned_discretionary` is everyday spending outside recurring bills. Since
`TRANSACTIONS` stores which recurring created it, the calibration hint computes
this exactly — so the input the user would struggle to produce is the one the
**Use** button fills in.

---

## What changes

### Schema

* [X] Rename `ESTIMATED_EXPENSES_MONTHLY` → `EVERYDAY_SPENDING_MONTHLY`
  (SQLite 3.25+ supports `ALTER TABLE ... RENAME COLUMN`)
* [X] `UPDATE WALLETS SET EVERYDAY_SPENDING_MONTHLY = NULL;` — the stored value
  is on the old basis, roughly a month of bills too high
* [X] Do **not** add `PLAN_INCLUDES_TRANSFERS`

### Service

* [X] Hint query gains one line:

```sql
WHERE wallet_id = ? AND operation_type = 'Expense'
  AND recurring_id IS NULL            -- new
  AND date >= ? AND date < ?
```

* [X] Hint label → `Last 6 months, everyday spending: 3 715,50`
* [X] Income query unchanged — a salary is scheduled, netting never applied to it

### Forecast

* [X] `est_other = planned_discretionary` — constant, no netting
* [ ] **One clamp survives, current month only:**

```python
est_other = max(0.0, planned_discretionary - actual_discretionary)
```

  Without it the current month double-counts everyday spending already recorded
  as real transactions.

* [X] `over_plan_by` exists only on the current month, meaning "you have used
  more of your everyday budget than planned". Future months have no cap to
  exceed.
* [X] `ForecastInputs` drops `plan_includes_transfers`

### Dialog

* [X] Field label → "Everyday spending", sub-text → "monthly, excluding
  scheduled bills and transfers"
* [X] No basis `SegmentedControl` — the question no longer exists
* [X] Month-window `SegmentedControl` stays as built

---

## What this removes

- The basis flag, its column, its widget, and its three readers
- The `max(0, ...)` clamp everywhere except the current month
- `over_plan_by` on future months — the semantic conflation flagged in the
  mockup review (a warning triangle on a month that has not happened)
- Partial-overlap error, entirely — the two inputs are disjoint by definition

---

## Measure it, do not subtract it

`planned_discretionary` is **not** "total minus scheduled". It is a directly
measured quantity: expenses with no recurring link. The two agree when
everything reconciles, but the filter cannot be wrong, whereas the subtraction
depends on the user's total being a true superset of their recurrings — the
assumption this change exists to remove.

---

## The two columns

`expenses` is **named** money — every złoty belongs to a transaction that either
happened or is scheduled with a known date and amount.

`est_other` is **unnamed** money — spending that will happen but cannot be
itemised in advance.

They are one quantity being converted, not two buckets. In the current month,
everyday spending moves from `est_other` into `expenses` as it is recorded, and
`closing` does not move. The forecast only changes when the user spends
*differently* from plan.

```
actual everyday + est_other = planned everyday        (current month)
```

---

## Worked example — 16 Nov 2026

Opening (1 Nov) 862,05 · planned income 7 902,35 · everyday spending 3 715,50 ·
floor 2 500,00
Recurring: Czynsz 637,50 (5th) · Internet 69,00 (10th) · Prąd 400,00 (18th) ·
Ubezpieczenie 178,00 (22nd) · Oszczędności 500,00 (25th) · Inwestycje 300,00 (25th)

|                           | Opening  | Income   | Expenses | Savings | Invest. | Est. other | Closing            |
| ------------------------- | -------- | -------- | -------- | ------- | ------- | ---------- | ------------------ |
| **lis** `to date` | 862,05   | 7 902,35 | 3 124,70 | 500,00  | 300,00  | 1 875,30   | **2 964,40** |
| **gru**             | 2 964,40 | 7 902,35 | 1 284,50 | 500,00  | 300,00  | 3 715,50   | **5 066,75** |

November:

```
expenses   3 124,70 =   706,50 bills paid (5th, 10th)
                     + 1 840,20 everyday so far  (recurring_id IS NULL)
                     +   578,00 still scheduled  (18th, 22nd)
est_other  1 875,30 = 3 715,50 planned − 1 840,20 already spent
```

Cross-check: a typical month costs `1 284,50 + 500 + 300 + 3 715,50 = 5 800,00`
against 7 902,35 income — surplus **+2 102,35/month**. November's total outflow
is exactly 5 800,00 (nothing unusual happened), and
`862,05 + 2 102,35 = 2 964,40`, matching the row arithmetic independently.

---

## Optional, deferred

- **Variance chip** — `scheduled_expenses − average_scheduled` as a signed chip
  beside the Expenses cell, answering "is this month heavier than usual".
  Display only, never in the arithmetic. Not required for v1.
- **Column header** — "Est. other" reads like "other categories". Something like
  `Everyday (est.)` says what it is and makes the current month's shrinking
  number self-explanatory.
